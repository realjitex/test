#!/bin/bash
# ╔══════════════════════════════════════════════════════════════╗
# ║              StatusPlugin Build Script                        ║
# ║   Compiles and packages the plugin into a JAR file            ║
# ╚══════════════════════════════════════════════════════════════╝

set -e

# Configuration
PLUGIN_NAME="EchoTab"
PLUGIN_VERSION="1.0.0"
JDK_PATH="${JDK_HOME:-/tmp/jdk-21.0.4+7}"

# Resolve script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  Building $PLUGIN_NAME v$PLUGIN_VERSION"
echo "╚══════════════════════════════════════════════════════════════╝"

# Check JDK
JAVAC="$JDK_PATH/bin/javac"
JAR_TOOL="$JDK_PATH/bin/jar"

if [ ! -f "$JAVAC" ]; then
    echo "✗ javac not found at: $JAVAC"
    echo "  Set JDK_HOME environment variable or install JDK 21"
    echo "  Example: export JDK_HOME=/usr/lib/jvm/java-21-openjdk-amd64"
    exit 1
fi

echo "→ Using JDK: $JDK_PATH"
echo "→ javac version: $($JAVAC -version 2>&1)"

# Clean
echo "→ Cleaning build directory..."
rm -rf build
mkdir -p build

# Find source files
find src/main/java -name "*.java" > sources.txt
SOURCE_COUNT=$(wc -l < sources.txt)
echo "→ Found $SOURCE_COUNT source files"

# Compile
echo "→ Compiling..."
$JAVAC -cp "lib/*" -d build @sources.txt
if [ $? -ne 0 ]; then
    echo "✗ Compilation failed!"
    rm -f sources.txt
    exit 1
fi
echo "✓ Compilation successful"

# Copy resources
echo "→ Copying resources..."
cp -r src/main/resources/* build/

# Package JAR
OUTPUT="${PLUGIN_NAME}-${PLUGIN_VERSION}.jar"
echo "→ Packaging $OUTPUT..."
cd build
$JAR_TOOL cf "../$OUTPUT" .
cd ..

# Cleanup
rm -f sources.txt
rm -rf build

# Done
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║  ✓ Build complete!                                            ║"
echo "║  Output: $OUTPUT"
echo "║"
echo "║  Install: Copy this JAR to your server's plugins/ folder     ║"
echo "╚══════════════════════════════════════════════════════════════╝"
ls -la "$OUTPUT"
