# EchoTab — Символ-префикс + Градиент ника для Paper 1.21.11

Майнкрафт плагин для **Paper 1.21.11**, который отображает в TAB-листе красивый **символ-префикс** и **градиентный ник**.

Решает проблему, с которой не справился LuckPerms: два префикса (символ + градиент) не перекрывают друг друга, потому что EchoTab использует **разные слоты** TAB:
- **Префикс** (symbol) → `TabListFormatManager.setPrefix()`
- **Имя** (gradient nickname) → `TabListFormatManager.setName()`
- **Суффикс** (статус) → оставляется для StatusPlugin

```
Формат в табе:  [♛] [N̳i̳c̳k̳] [ AFK ]
                  ↑     ↑       ↑
               символ  градиент  статус (от StatusPlugin)
```

---

## Возможности

- **10 готовых символов-префиксов** (корона, вихрь, молния, звезда и др.)
- **10 готовых градиентов** ника (огонь, океан, галактика, радуга и др.)
- **Назначение через LuckPerms** — выдай игроку permission на символ и/или градиент
- **Не перекрывает суффикс** — статус от StatusPlugin остаётся в конце
- **Приоритеты** — если выдано несколько, выигрывает с высшим приоритетом
- **TAB v5 API** через reflection (без жёсткой зависимости)
- **Bukkit fallback** если TAB не установлен
- **Авто-обновление** каждые 30 секунд (ловит изменения прав)

---

## Требования

- **Paper 1.21.11** (или любая 1.21.x)
- **Java 21+**
- **[TAB плагин](https://github.com/NEZNAMY/TAB)** v5+ (рекомендуется)
- **[LuckPerms](https://luckperms.net/)** (для назначения символов/градиентов игрокам)

---

## Установка

1. Скопируйте `EchoTab-1.0.0.jar` в папку `plugins/`
2. Перезапустите сервер
3. Настройте `plugins/EchoTab/config.yml` при необходимости

### ⚠️ Важно: настройка TAB

В `plugins/TAB/config.yml` должна быть включена функция:
```yaml
tablist-name-formatting:
  enabled: true    # ДОЛЖНО быть true!
```

---

## Быстрый старт

### 1. Выдать игроку символ и градиент

```bash
# Выдать корону (символ)
/lp user Steve permission set echotab.symbol.crown true

# Выдать огненный градиент
/lp user Steve permission set echotab.gradient.fire true
```

Готово! В табе появится: `♛ Steve` с огненным градиентом на нике.

### 2. Изменить символ/градиент

```bash
# Сменить символ на молнию
/lp user Steve permission set echotab.symbol.crown false
/lp user Steve permission set echotab.symbol.lightning true

# Сменить градиент на океан
/lp user Steve permission set echotab.gradient.fire false
/lp user Steve permission set echotab.gradient.ocean true
```

Изменения подхватятся в течение 30 секунд (refresh-interval) или сразу через `/echotab apply`.

---

## Символы (10 пресетов)

| Название | Символ | Цвет | Permission |
|----------|--------|------|------------|
| `crown` | ♛ | Золотой | `echotab.symbol.crown` |
| `vortex` | ✺ | Пурпурный | `echotab.symbol.vortex` |
| `lightning` | ⚡ | Жёлтый | `echotab.symbol.lightning` |
| `star` | ✦ | Голубой | `echotab.symbol.star` |
| `snowflake` | ❄ | Светло-голубой | `echotab.symbol.snowflake` |
| `fire` | ✸ | Красно-оранжевый | `echotab.symbol.fire` |
| `diamond` | ♦ | Cyan | `echotab.symbol.diamond` |
| `flower` | ❀ | Розовый | `echotab.symbol.flower` |
| `moon` | ☾ | Фиолетовый | `echotab.symbol.moon` |
| `sun` | ☀ | Оранжевый | `echotab.symbol.sun` |

---

## Градиенты (10 пресетов)

| Название | Цвета | Permission |
|----------|-------|------------|
| `fire` | 🔴 Красный → 🟠 Оранжевый → 🟡 Жёлтый | `echotab.gradient.fire` |
| `ocean` | 🔵 Синий → 🔷 Голубой → ⬜ Светло-голубой | `echotab.gradient.ocean` |
| `forest` | 🟢 Тёмно-зелёный → 🟩 Зелёный → 🟡 Лайм | `echotab.gradient.forest` |
| `sunset` | 🟣 Фиолетовый → 🩷 Розовый → 🟠 Оранжевый | `echotab.gradient.sunset` |
| `galaxy` | ⬛ Тёмно-фиолетовый → 🟣 Фиолетовый → 🟪 Пурпурный | `echotab.gradient.galaxy` |
| `gold` | 🟤 Тёмное золото → 🟡 Золото → ⬜ Кремовый | `echotab.gradient.gold` |
| `ice` | ⬜ Белый → ⬜ Светло-голубой → 🔷 Голубой | `echotab.gradient.ice` |
| `rainbow` | 🌈 Радуга (7 цветов) | `echotab.gradient.rainbow` |
| `lavender` | 🟣 Пурпурный → 🟪 Лавандовый → ⬜ Светлый | `echotab.gradient.lavender` |
| `mint` | 🟢 Тёмный teal → 🟩 Мятный → ⬜ Светлый | `echotab.gradient.mint` |
| `white` | ⬜ Белый (по умолчанию) | `echotab.gradient.white` |

---

## Команды

| Команда | Описание | Право |
|---------|----------|-------|
| `/echotab reload` | Перезагрузить конфиг | `echotab.admin` |
| `/echotab apply [player]` | Применить форматирование (себе или игроку) | `echotab.use` / `echotab.admin` |
| `/echotab applyall` | Применить ко всем онлайн-игрокам | `echotab.admin` |
| `/echotab list` | Список всех символов и градиентов | `echotab.use` |

Алиас команды: `/etab`

---

## Конфигурация

Файл: `plugins/EchoTab/config.yml`

### Основные настройки

```yaml
settings:
  refresh-interval: 30      # обновление каждые N секунд
  join-delay: 40            # задержка при входе (в тиках, 20 = 1 сек)
  apply-gradient-to-name: true  # применять градиент к нику

defaults:
  symbol: ""                # символ по умолчанию (пусто = нет символа)
  gradient: "white"         # градиент по умолчанию
  default-name-color: "&f"   # цвет ника без градиента
```

### Добавление своего символа

```yaml
symbols:
  my-custom-symbol:
    display: "&#A020F0⚡&r &l"  # фиолетовая молния + пробел + сброс
    permission: "echotab.symbol.custom"
    priority: 110              # выше = приоритетнее
```

### Добавление своего градиента

```yaml
gradients:
  my-gradient:
    colors: ["#FF1493", "#FF69B4", "#FFB6C1"]  # розовые оттенки
    permission: "echotab.gradient.mygradient"
    priority: 110
```

---

## Как это работает

### Архитектура

```
Игрок входит
    │
    ▼
PlayerListener.onJoin()
    │ (задержка 2 сек для загрузки TAB)
    ▼
TabFormatter.applyFormatting(player)
    │
    ├── ConfigManager.resolveSymbol(player)     → проверяет permissions
    ├── ConfigManager.resolveGradient(player)    → проверяет permissions
    │
    ├── GradientGenerator.applyGradient(name, colors)  → генерирует цветной ник
    │
    └── TAB API (reflection):
            setPrefix(tabPlayer, symbol)   → символ-префикс
            setName(tabPlayer, gradientName) → градиентный ник
```

### Слоты TAB

TAB использует три независимых слота для отображения:
```
[tabprefix] + [customtabname] + [tabsuffix]
     ↑              ↑               ↑
  символ (EchoTab)  градиент (EchoTab)  статус (StatusPlugin)
```

Поскольку EchoTab пишет только в `prefix` и `name`, а StatusPlugin — только в `suffix`, **они не конфликтуют**.

### Градиент

Градиент применяется посимвольно. Например, ник "Steve" с градиентом fire (`["#FF0000", "#FF6600", "#FFCC00"]`):

```
&#FF0000S&#FF3300t&#FF6600e&#FF9900v&#FFCC00e
  красный   →    →    →    →  жёлтый
```

Каждый символ получает интерполированный цвет между стопами градиента.

---

## Совместимость с другими плагинами

| Плагин | Совместимость |
|--------|--------------|
| **TAB** | ✅ Основная интеграция (TAB v5 API) |
| **LuckPerms** | ✅ Используется для назначения символов/градиентов |
| **StatusPlugin** | ✅ Не конфликтует (разные слоты TAB) |
| **FlectonePulse** | ⚠️ Может конфликтовать, если тоже управляет prefix/name. Настройте FlectonePulse, чтобы не трогал таб-префикс. |
| **PlaceholderAPI** | ✅ Не обязателен, но поддерживается |

---

## Устранение неполадок

### Символ/градиент не отображается

1. **Проверьте TAB**: `plugins/TAB/config.yml` → `tablist-name-formatting.enabled: true`
2. **Проверьте permissions**: `/lp user <player> info has echotab.symbol.crown`
3. **Примените вручную**: `/echotab apply <player>`
4. **Смотрите лог**: проверьте консоль на ошибки TAB API

### Символ отображается квадратиком

Некоторые Unicode-символы могут не отображаться без ресурсного пакета. Замените символ в `config.yml` на поддерживаемый (♛, ★, ✦, ❄, ♦ рендерятся в vanilla-шрифте).

### FlectonePulse перебивает формат

EchoTab обновляет префикс каждые 30 секунд. Если FlectonePulse тоже пишет в prefix, отключите форматирование таб-листа в FlectonePulse или увеличьте `refresh-interval` в EchoTab.

### Несколько символов у одного игрока

Если игрок имеет несколько permissions на символы, выигрывает тот, у которого **priority** выше в конфиге. Чтобы убрать символ, снимите permission:
```bash
/lp user Steve permission set echotab.symbol.crown false
```

---

## Сборка из исходников

```bash
chmod +x build.sh
./build.sh
```

Требуется JDK 21+ (библиотеки уже в папке `lib/`).

---

## Структура проекта

```
echotab-plugin/
├── src/main/java/ru/echotab/
│   ├── EchoTab.java              # главный класс
│   ├── ConfigManager.java        # загрузка символов и градиентов
│   ├── GradientGenerator.java    # генератор градиентов
│   ├── TabFormatter.java         # TAB API (setPrefix + setName)
│   ├── listeners/
│   │   └── PlayerListener.java   # вход/выход игроков
│   └── commands/
│       └── EchoTabCommand.java   # /echotab reload|apply|list
├── src/main/resources/
│   ├── plugin.yml
│   └── config.yml                # 10 символов + 10 градиентов
├── lib/                          # зависимости
├── build.sh                      # скрипт сборки
└── README.md
```

---

## Примеры использования

### VIP-игрок: корона + золото
```bash
/lp user VIP_Player permission set echotab.symbol.crown true
/lp user VIP_Player permission set echotab.gradient.gold true
```
Результат: `♛ VIP_Player` с золотым градиентом

### Стример: молния + радуга
```bash
/lp user Streamer permission set echotab.symbol.lightning true
/lp user Streamer permission set echotab.gradient.rainbow true
```
Результат: `⚡ Streamer` с радужным градиентом

### Админ: алмаз + галактика
```bash
/lp user Admin permission set echotab.symbol.diamond true
/lp user Admin permission set echotab.gradient.galaxy true
```
Результат: `♦ Admin` с галактическим градиентом

### Без символа, только градиент
```bash
/lp user Player permission set echotab.gradient.ocean true
```
Результат: `Player` с океанским градиентом (без символа-префикса)

### Совместно со StatusPlugin
Если установлен StatusPlugin, игрок с AFK получит:
```
♛ VIP_Player [AFK]
```
Символ ♛ + золотой градиент + серый бейдж AFK в конце.

---

## Технические детали

### TAB v5 API (reflection)

```java
TabAPI.getInstance()                              → TabAPI
TabAPI.getPlayer(UUID)                           → TabPlayer
TabAPI.getTabListFormatManager()                → TabListFormatManager
TabListFormatManager.setPrefix(tabPlayer, symbol) → символ-префикс
TabListFormatManager.setName(tabPlayer, name)     → градиентный ник
```

### Приоритет разрешения

Если у игрока несколько permissions на символы:
1. Выбирается символ с **наивысшим priority**
2. При равных priority — первый в конфиге

### Цветовые коды

| Формат | Пример | Описание |
|--------|--------|----------|
| `&#RRGGBB` | `&#FF0000` | Hex цвет |
| `&0-9`, `&a-f` | `&c` | Стандартные цвета |
| `&l`, `&o`, `&n` | `&l` | Жирный, курсив, подчёркивание |
| `&r` | `&r` | Сброс |

---

## Лицензия

Свободное использование.

---

## Совместимость

- ✅ Paper 1.21.11 (все 1.21.x)
- ✅ TAB v5+
- ✅ LuckPerms
- ✅ StatusPlugin (совместное использование)
- ✅ Java 21+
