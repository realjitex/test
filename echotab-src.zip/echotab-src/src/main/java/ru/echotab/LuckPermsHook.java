package ru.echotab;

import org.bukkit.Bukkit;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

/**
 * Hooks into the LuckPerms API via reflection to query EXPLICIT permission grants.
 *
 * This is necessary because Bukkit's {@code Player.hasPermission()} returns true
 * for OP players for ANY permission, and also resolves wildcards. This makes it
 * impossible to distinguish between:
 *   - a permission that was explicitly granted via LuckPerms
 *   - a permission that is "true" just because the player is OP
 *
 * By querying LuckPerms directly, we only see permissions that were actually
 * assigned (TRUE), negated (FALSE), or not set (UNDEFINED). OP status is ignored.
 *
 * This means OP players will NOT automatically receive all symbols/gradients —
 * they must explicitly grant themselves the ones they want.
 *
 * LuckPerms API flow (all via reflection, no hard compile dependency):
 *   LuckPermsProvider.get()                              → LuckPerms
 *   luckPerms.getUserManager()                           → UserManager
 *   userManager.getUser(UUID)                            → User (nullable if not loaded)
 *   user.getCachedData()                                 → CachedDataManager
 *   cachedData.getPermissionData()                       → CachedPermissionData
 *   cachedPermissionData.checkPermission(String)         → Tristate (TRUE/FALSE/UNDEFINED)
 *
 * Tristate.asBoolean() returns true ONLY for TRUE (explicit grant).
 * UNDEFINED (OP or not set) → false, FALSE (negated) → false.
 *
 * If getUser() returns null (user not loaded), we fall back to loading the user
 * asynchronously via loadUser() and cache the result for a short time.
 */
public class LuckPermsHook {

    private final EchoTab plugin;
    private boolean checked = false;
    private boolean available = false;
    private Method getLuckPermsMethod;
    private Method getUserManagerMethod;
    private Method getUserMethod;
    private Method loadUserMethod;
    private Method getCachedDataMethod;
    private Method getPermissionDataMethod;
    private Method checkPermissionMethod;
    private Method getPermissionMapMethod;
    private Method tristateAsBooleanMethod;

    // Cache of loaded users (UUID -> User object) so we don't reload on every check.
    // Cleared periodically.
    private final ConcurrentHashMap<UUID, Long> lastLoadAttempt = new ConcurrentHashMap<>();

    public LuckPermsHook(EchoTab plugin) {
        this.plugin = plugin;
    }

    /**
     * Lazily checks if LuckPerms is available and caches reflection methods.
     * Tries LuckPermsProvider.get() first, then Bukkit ServicesManager.
     */
    private void ensureChecked() {
        if (checked) return;
        checked = true;

        if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            plugin.getLogger().info("LuckPerms not found. EchoTab will use Bukkit permission checks (OPs will get all presets).");
            return;
        }

        try {
            Class<?> luckPermsClass = Class.forName("net.luckperms.api.LuckPerms");

            // Try LuckPermsProvider.get() first
            Object luckPerms = null;
            try {
                Class<?> providerClass = Class.forName("net.luckperms.api.LuckPermsProvider");
                getLuckPermsMethod = providerClass.getMethod("get");
                luckPerms = getLuckPermsMethod.invoke(null);
            } catch (ClassNotFoundException e) {
                plugin.getLogger().warning("LuckPermsProvider class not found, trying Bukkit ServicesManager...");
            }

            // Fallback: Bukkit ServicesManager
            if (luckPerms == null) {
                try {
                    Object registration = Bukkit.getServicesManager().getRegistration(luckPermsClass);
                    if (registration != null) {
                        // Use reflection to call getProvider() — the registration type is
                        // RegisteredServiceProvider<?>, which the compiler can't resolve here.
                        Method getProviderMethod = registration.getClass().getMethod("getProvider");
                        luckPerms = getProviderMethod.invoke(registration);
                        plugin.getLogger().info("LuckPerms obtained via Bukkit ServicesManager.");
                    }
                } catch (Exception e) {
                    plugin.getLogger().warning("Failed to get LuckPerms via ServicesManager: " + e.getMessage());
                }
            }

            if (luckPerms == null) {
                plugin.getLogger().warning("Could not obtain LuckPerms instance. Falling back to Bukkit permission checks.");
                return;
            }

            getUserManagerMethod = luckPermsClass.getMethod("getUserManager");

            Class<?> userManagerClass = getUserManagerMethod.getReturnType();

            // UserManager.getUser(UUID) → User (nullable)
            try {
                getUserMethod = userManagerClass.getMethod("getUser", UUID.class);
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find UserManager.getUser(UUID) method: " + e.getMessage());
                return;
            }

            // UserManager.loadUser(UUID) → CompletableFuture<User> (for async load)
            try {
                loadUserMethod = userManagerClass.getMethod("loadUser", UUID.class);
            } catch (NoSuchMethodException e) {
                loadUserMethod = null;
            }

            Class<?> userClass = getUserMethod.getReturnType();
            getCachedDataMethod = userClass.getMethod("getCachedData");

            Class<?> cachedDataClass = getCachedDataMethod.getReturnType();
            getPermissionDataMethod = cachedDataClass.getMethod("getPermissionData");

            Class<?> permDataClass = getPermissionDataMethod.getReturnType();
            try {
                checkPermissionMethod = permDataClass.getMethod("checkPermission", String.class);
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find CachedPermissionData.checkPermission method: " + e.getMessage());
                return;
            }

            // CachedPermissionData.getPermissionMap() → Map<String, Boolean>
            // This returns the RAW permission map with EXACT node keys (wildcards NOT expanded).
            // We use this to check for exact permission matches, bypassing wildcard resolution.
            try {
                getPermissionMapMethod = permDataClass.getMethod("getPermissionMap");
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find CachedPermissionData.getPermissionMap method.");
                getPermissionMapMethod = null;
            }

            Class<?> tristateClass = checkPermissionMethod.getReturnType();
            try {
                tristateAsBooleanMethod = tristateClass.getMethod("asBoolean");
            } catch (NoSuchMethodException e) {
                tristateAsBooleanMethod = null;
            }

            available = true;
            plugin.getLogger().info("LuckPerms API hooked successfully (EchoTab). Explicit permission checks enabled.");
            plugin.getLogger().info("  Tristate class: " + tristateClass.getName());
            plugin.getLogger().info("  OP players will only get presets they explicitly granted themselves.");

        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("LuckPerms API class not found: " + e.getMessage());
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to hook into LuckPerms API: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Returns true ONLY if the permission is explicitly granted as TRUE in LuckPerms.
     *
     * This bypasses OP status, wildcards that don't resolve to explicit nodes,
     * and default permissions. Returns false for UNDEFINED (not set) and FALSE (negated).
     *
     * @param uuid       the player's UUID
     * @param permission the permission node to check
     * @return true only if LuckPerms explicitly grants TRUE
     */
    public boolean isExplicitlyTrue(UUID uuid, String permission) {
        ensureChecked();
        if (!available) return false;

        try {
            Object luckPerms = getLuckPermsMethod.invoke(null);
            Object userManager = getUserManagerMethod.invoke(luckPerms);
            Object user = getUserMethod.invoke(userManager, uuid);

            // User may be null if not yet loaded by LuckPerms
            if (user == null) {
                // Try to load the user asynchronously (only once per minute per player to avoid spam)
                tryLoadUser(uuid, userManager);
                return false;
            }

            Object cachedData = getCachedDataMethod.invoke(user);
            Object permData = getPermissionDataMethod.invoke(cachedData);
            Object tristate = checkPermissionMethod.invoke(permData, permission);

            if (tristate == null) return false;

            if (tristateAsBooleanMethod != null) {
                Object result = tristateAsBooleanMethod.invoke(tristate);
                return Boolean.TRUE.equals(result);
            }

            // Fallback: compare enum name
            return "TRUE".equalsIgnoreCase(tristate.toString());

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns true ONLY if the permission is set as an EXACT node with value TRUE
     * in the LuckPerms permission map. This completely bypasses wildcard resolution.
     *
     * Unlike {@link #isExplicitlyTrue(UUID, String)} which uses checkPermission() (and
     * therefore resolves wildcards like echotab.* → echotab.symbol.crown), this method
     * looks up the RAW permission map for an exact key match.
     *
     * This means:
     *   - echotab.symbol.crown = true  → returns TRUE (exact match)
     *   - echotab.* = true             → returns FALSE (key "echotab.symbol.crown" not in map)
     *   - echotab.symbol.* = true      → returns FALSE (key "echotab.symbol.crown" not in map)
     *   - * = true                     → returns FALSE (key "echotab.symbol.crown" not in map)
     *
     * The map includes inherited group permissions, so if a group has an exact node
     * echotab.symbol.crown = true, this will return TRUE for members of that group.
     *
     * @param uuid       the player's UUID
     * @param permission the EXACT permission node to check (no wildcard expansion)
     * @return true only if the exact key exists in the permission map with value true
     */
    @SuppressWarnings("unchecked")
    public boolean isExactNodeTrue(UUID uuid, String permission) {
        ensureChecked();
        if (!available) return false;

        // If getPermissionMap method is not available, fall back to isExplicitlyTrue
        if (getPermissionMapMethod == null) {
            return isExplicitlyTrue(uuid, permission);
        }

        try {
            Object luckPerms = getLuckPermsMethod.invoke(null);
            Object userManager = getUserManagerMethod.invoke(luckPerms);
            Object user = getUserMethod.invoke(userManager, uuid);

            if (user == null) {
                tryLoadUser(uuid, userManager);
                return false;
            }

            Object cachedData = getCachedDataMethod.invoke(user);
            Object permData = getPermissionDataMethod.invoke(cachedData);
            Object map = getPermissionMapMethod.invoke(permData);

            if (map instanceof java.util.Map) {
                java.util.Map<String, Boolean> permMap = (java.util.Map<String, Boolean>) map;
                Boolean value = permMap.get(permission);
                return Boolean.TRUE.equals(value);
            }

            return false;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns all echotab-related permission map entries for a player (for debugging).
     */
    @SuppressWarnings("unchecked")
    public java.util.Map<String, Boolean> getPermissionMapSnapshot(UUID uuid) {
        ensureChecked();
        java.util.Map<String, Boolean> result = new java.util.LinkedHashMap<>();
        if (!available || getPermissionMapMethod == null) return result;

        try {
            Object luckPerms = getLuckPermsMethod.invoke(null);
            Object userManager = getUserManagerMethod.invoke(luckPerms);
            Object user = getUserMethod.invoke(userManager, uuid);

            if (user == null) return result;

            Object cachedData = getCachedDataMethod.invoke(user);
            Object permData = getPermissionDataMethod.invoke(cachedData);
            Object map = getPermissionMapMethod.invoke(permData);

            if (map instanceof java.util.Map) {
                java.util.Map<String, Boolean> permMap = (java.util.Map<String, Boolean>) map;
                for (java.util.Map.Entry<String, Boolean> entry : permMap.entrySet()) {
                    String key = entry.getKey();
                    if (key != null && (key.startsWith("echotab") || key.equals("*"))) {
                        result.put(key, entry.getValue());
                    }
                }
            }
        } catch (Exception e) {
            // Ignore
        }
        return result;
    }

    /**
     * Asynchronously loads a user into LuckPerms cache if they're not loaded.
     * Throttled to once per minute per player to avoid spam.
     */
    private void tryLoadUser(UUID uuid, Object userManager) {
        long now = System.currentTimeMillis();
        Long last = lastLoadAttempt.get(uuid);
        if (last != null && (now - last) < 60000) {
            return; // Already attempted recently
        }
        lastLoadAttempt.put(uuid, now);

        if (loadUserMethod == null) return;

        // Run async to avoid blocking the main thread
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Object future = loadUserMethod.invoke(userManager, uuid);
                if (future != null) {
                    // Try to join the CompletableFuture to ensure the user gets loaded
                    try {
                        Class<?> futureClass = future.getClass();
                        Method getMethod = futureClass.getMethod("get");
                        getMethod.invoke(future);
                    } catch (Exception ignored) {
                        // CompletableFuture.get() may throw ExecutionException — ignore
                    }
                }
            } catch (Exception e) {
                // Ignore
            }
        });
    }

    /**
     * Returns whether the LuckPerms hook is available.
     * If false, callers should fall back to Bukkit's permission checks.
     */
    public boolean isAvailable() {
        ensureChecked();
        return available;
    }

    /**
     * Returns debug info about the LuckPerms hook state.
     */
    public String getDebugInfo() {
        ensureChecked();
        StringBuilder sb = new StringBuilder();
        sb.append("LuckPerms hook available: ").append(available).append("\n");
        if (available) {
            sb.append("  getLuckPermsMethod: ").append(getLuckPermsMethod != null ? "OK" : "null").append("\n");
            sb.append("  getUserManagerMethod: ").append(getUserManagerMethod != null ? "OK" : "null").append("\n");
            sb.append("  getUserMethod: ").append(getUserMethod != null ? "OK" : "null").append("\n");
            sb.append("  loadUserMethod: ").append(loadUserMethod != null ? "OK" : "null").append("\n");
            sb.append("  getCachedDataMethod: ").append(getCachedDataMethod != null ? "OK" : "null").append("\n");
            sb.append("  getPermissionDataMethod: ").append(getPermissionDataMethod != null ? "OK" : "null").append("\n");
            sb.append("  checkPermissionMethod: ").append(checkPermissionMethod != null ? "OK" : "null").append("\n");
            sb.append("  tristateAsBooleanMethod: ").append(tristateAsBooleanMethod != null ? "OK" : "null").append("\n");
        }
        return sb.toString();
    }

    /**
     * Returns detailed debug info about a permission: its Tristate value and the
     * source (which group/holder granted it). Used by the /echotab debug command.
     *
     * Uses CachedPermissionData.queryPermission() which returns Result<Tristate, Node>.
     * The Node carries InheritanceOriginMetadata telling us WHERE the permission came from.
     */
    public String getPermissionDebug(UUID uuid, String permission) {
        ensureChecked();
        StringBuilder sb = new StringBuilder();
        sb.append("Permission: ").append(permission).append("\n");

        if (!available) {
            sb.append("  LuckPerms hook not available.\n");
            return sb.toString();
        }

        try {
            Object luckPerms = getLuckPermsMethod.invoke(null);
            Object userManager = getUserManagerMethod.invoke(luckPerms);
            Object user = getUserMethod.invoke(userManager, uuid);

            if (user == null) {
                sb.append("  User not loaded in LuckPerms (try again in a moment).\n");
                return sb.toString();
            }

            Object cachedData = getCachedDataMethod.invoke(user);
            Object permData = getPermissionDataMethod.invoke(cachedData);

            // Try queryPermission() to get Result<Tristate, Node> with source info
            try {
                Class<?> permDataClass = permData.getClass();
                Method queryPermissionMethod = permDataClass.getMethod("queryPermission", String.class);
                Object result = queryPermissionMethod.invoke(permData, permission);

                if (result != null) {
                    // Result.result() → Tristate
                    Class<?> resultClass = result.getClass();
                    Method resultMethod = resultClass.getMethod("result");
                    Object tristate = resultMethod.invoke(result);
                    sb.append("  Tristate: ").append(tristate != null ? tristate : "null").append("\n");

                    // Result.node() → Node (the node that caused this result)
                    Method nodeMethod = resultClass.getMethod("node");
                    Object node = nodeMethod.invoke(result);

                    if (node != null) {
                        Class<?> nodeClass = node.getClass();
                        // Node.getKey() → the permission key (might be a wildcard)
                        try {
                            Method getKeyMethod = nodeClass.getMethod("getKey");
                            Object key = getKeyMethod.invoke(node);
                            sb.append("  Node key: ").append(key).append("\n");
                        } catch (Exception ignored) {}

                        // Try to get the inheritance origin (which holder granted this)
                        // via InheritanceOriginMetadata
                        try {
                            Class<?> metaClass = Class.forName("net.luckperms.api.node.metadata.types.InheritanceOriginMetadata");
                            Class<?> nodeMetaClass = Class.forName("net.luckperms.api.node.metadata.NodeMetadataKey");
                            // InheritanceOriginMetadata.KEY is a static field
                            java.lang.reflect.Field keyField = metaClass.getField("KEY");
                            Object originKey = keyField.get(null);

                            // Node.getMetadata(NodeMetadataKey) → Optional<InheritanceOriginMetadata>
                            Class<?> absNodeClass = Class.forName("net.luckperms.api.node.Node");
                            Method getMetadataMethod = absNodeClass.getMethod("getMetadata", nodeMetaClass);
                            Object optional = getMetadataMethod.invoke(node, originKey);

                            if (optional != null) {
                                // Optional.orElse(null) or .get()
                                Class<?> optionalClass = optional.getClass();
                                try {
                                    Method isPresentMethod = optionalClass.getMethod("isPresent");
                                    Object isPresent = isPresentMethod.invoke(optional);
                                    if (Boolean.TRUE.equals(isPresent)) {
                                        Method getOptMethod = optionalClass.getMethod("get");
                                        Object origin = getOptMethod.invoke(optional);

                                        // InheritanceOriginMetadata: getHolder() and getLocation()
                                        Class<?> originClass = origin.getClass();
                                        try {
                                            Method getHolderMethod = originClass.getMethod("getHolder");
                                            Object holder = getHolderMethod.invoke(origin);
                                            sb.append("  Granted by: ").append(holder).append("\n");
                                        } catch (Exception ignored) {}

                                        try {
                                            Method getLocationMethod = originClass.getMethod("getLocation");
                                            Object location = getLocationMethod.invoke(origin);
                                            if (location != null) sb.append("  Location: ").append(location).append("\n");
                                        } catch (Exception ignored) {}
                                    }
                                } catch (Exception ignored) {}
                            }
                        } catch (Exception ignored) {
                            // Metadata API not available — skip
                        }
                    } else {
                        sb.append("  Node: null (no explicit node — likely default/UNDEFINED)\n");
                    }
                }
            } catch (NoSuchMethodException e) {
                // queryPermission not available — fall back to checkPermission
                Object tristate = checkPermissionMethod.invoke(permData, permission);
                sb.append("  Tristate: ").append(tristate != null ? tristate : "null").append("\n");
                sb.append("  (queryPermission not available — cannot determine source)\n");
            }

        } catch (Exception e) {
            sb.append("  Error: ").append(e.getMessage()).append("\n");
        }

        return sb.toString();
    }
}
