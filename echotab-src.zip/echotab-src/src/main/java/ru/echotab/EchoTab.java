package ru.echotab;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import ru.echotab.commands.EchoTabCommand;
import ru.echotab.listeners.PlayerListener;

/**
 * EchoTab — Symbol prefix + Gradient nickname plugin for Paper 1.21.11.
 *
 * Displays a symbol prefix and a gradient-colored nickname in the TAB list:
 *   [symbol prefix] [gradient nickname] [status suffix]
 *
 * Symbols and gradients are assigned via LuckPerms permissions and configured
 * in config.yml. The plugin integrates with the TAB plugin (v5 API via reflection)
 * to set the prefix and name. The suffix is left to StatusPlugin or other plugins.
 *
 * Features:
 *  - 10 pre-made symbol prefixes (crown, vortex, lightning, star, etc.)
 *  - 10 pre-made nickname gradients (fire, ocean, galaxy, rainbow, etc.)
 *  - Permission-based assignment (LuckPerms integration)
 *  - Priority resolution if multiple perms are assigned
 *  - TAB v5 API integration via reflection (no hard dependency)
 *  - Bukkit fallback if TAB is not installed
 *  - Periodic refresh to handle permission changes
 */
public class EchoTab extends JavaPlugin {

    private static EchoTab instance;

    private ConfigManager configManager;
    private TabFormatter tabFormatter;
    private LuckPermsHook luckPermsHook;

    @Override
    public void onEnable() {
        instance = this;

        // Save default config
        saveDefaultConfig();

        // Initialize managers
        luckPermsHook = new LuckPermsHook(this);
        configManager = new ConfigManager(this, luckPermsHook);
        configManager.load();

        tabFormatter = new TabFormatter(this, configManager);

        // Register event listeners
        PlayerListener playerListener = new PlayerListener(this);
        getServer().getPluginManager().registerEvents(playerListener, this);

        // Register commands
        EchoTabCommand command = new EchoTabCommand(this);
        getCommand("echotab").setExecutor(command);
        getCommand("echotab").setTabCompleter(command);

        // Start periodic refresh task
        startRefreshTask();

        // Check for TAB plugin
        if (getServer().getPluginManager().getPlugin("TAB") != null) {
            boolean tabReady = tabFormatter.isTabAvailable();
            boolean featureEnabled = tabFormatter.isTabFeatureEnabled();
            if (tabReady && featureEnabled) {
                getLogger().info("TAB plugin detected! Formatting via TAB v5 API (TabListFormatManager).");
            } else if (tabReady && !featureEnabled) {
                getLogger().warning("TAB plugin detected, but 'tablist-name-formatting' feature is DISABLED!");
                getLogger().warning("Using Bukkit fallback. Enable the feature in plugins/TAB/config.yml.");
            } else {
                getLogger().warning("TAB plugin detected, but API hook failed. Using Bukkit fallback.");
            }
        } else {
            getLogger().warning("TAB plugin not found. Using Bukkit player list name (fallback mode).");
            getLogger().warning("For best results (separate prefix + name + suffix), install the TAB plugin.");
        }

        // Apply formatting to already-online players (after a delay for TAB to load)
        Bukkit.getScheduler().runTaskLater(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                tabFormatter.applyFormatting(player);
            }
        }, 60L); // 3 seconds

        getLogger().info("EchoTab enabled successfully!");
        getLogger().info("Symbols: " + configManager.getSymbols().size()
                + " | Gradients: " + configManager.getGradients().size());
    }

    @Override
    public void onDisable() {
        // Restore all online players' original display
        for (Player player : Bukkit.getOnlinePlayers()) {
            tabFormatter.restoreFormatting(player);
        }
        getLogger().info("EchoTab disabled.");
    }

    /**
     * Reloads the plugin configuration and refreshes all players.
     */
    public void reloadPluginConfig() {
        reloadConfig();
        configManager.load();
        // Refresh all online players
        for (Player player : Bukkit.getOnlinePlayers()) {
            tabFormatter.applyFormatting(player);
        }
    }

    /**
     * Starts the periodic refresh task that reapplies formatting to all
     * online players. This handles permission changes (e.g., LuckPerms
     * grant/revoke) without requiring a rejoin.
     */
    private void startRefreshTask() {
        int interval = configManager.getRefreshInterval() * 20; // Convert to ticks
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    tabFormatter.applyFormatting(player);
                }
            }
        }.runTaskTimer(this, interval, interval);
    }

    /**
     * Translates & color codes to § for Minecraft.
     */
    public static String colorize(String text) {
        if (text == null) return "";
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    /**
     * Sends a prefixed message to a player.
     */
    public void sendMessage(Player player, String message) {
        player.sendMessage(colorize(configManager.getMessagePrefix() + message));
    }

    /**
     * Sends a prefixed message to a command sender.
     */
    public void sendMessage(org.bukkit.command.CommandSender sender, String message) {
        sender.sendMessage(colorize(configManager.getMessagePrefix() + message));
    }

    // ─── Getters ────────────────────────────────────────────

    public static EchoTab getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public TabFormatter getTabFormatter() {
        return tabFormatter;
    }

    public LuckPermsHook getLuckPermsHook() {
        return luckPermsHook;
    }
}
