package ru.echotab;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Manages the EchoTab configuration.
 * Loads symbol prefixes and nickname gradients from config.yml.
 *
 * Symbols and gradients are stored in config order (LinkedHashMap preserves
 * insertion order). When resolving which symbol/gradient a player uses,
 * priority is checked first, then config order breaks ties.
 */
public class ConfigManager {

    private final EchoTab plugin;
    private final LuckPermsHook luckPermsHook;

    // Loaded presets
    private final LinkedHashMap<String, SymbolPreset> symbols = new LinkedHashMap<>();
    private final LinkedHashMap<String, GradientPreset> gradients = new LinkedHashMap<>();

    // General settings
    private int refreshInterval;
    private int joinDelay;
    private boolean applyGradientToName;

    // Defaults
    private String defaultSymbol;
    private String defaultGradient;
    private String defaultNameColor;

    // Messages
    private String messagePrefix;

    public ConfigManager(EchoTab plugin, LuckPermsHook luckPermsHook) {
        this.plugin = plugin;
        this.luckPermsHook = luckPermsHook;
    }

    /**
     * Loads (or reloads) all configuration values.
     */
    public void load() {
        FileConfiguration config = plugin.getConfig();

        // Clear existing
        symbols.clear();
        gradients.clear();

        // General settings
        refreshInterval = config.getInt("settings.refresh-interval", 30);
        joinDelay = config.getInt("settings.join-delay", 40);
        applyGradientToName = config.getBoolean("settings.apply-gradient-to-name", true);

        // Defaults
        defaultSymbol = config.getString("defaults.symbol", "");
        defaultGradient = config.getString("defaults.gradient", "white");
        defaultNameColor = config.getString("defaults.default-name-color", "&f");

        // Messages
        messagePrefix = EchoTab.colorize(config.getString("messages.prefix", "&8[&bEchoTab&8] &r"));

        // Load symbols
        ConfigurationSection symbolsSection = config.getConfigurationSection("symbols");
        if (symbolsSection != null) {
            for (String key : symbolsSection.getKeys(false)) {
                ConfigurationSection sym = symbolsSection.getConfigurationSection(key);
                if (sym == null) continue;
                String display = sym.getString("display", "");
                String permission = sym.getString("permission", "echotab.symbol." + key);
                int priority = sym.getInt("priority", 0);
                symbols.put(key, new SymbolPreset(key, display, permission, priority));
            }
        }

        // Load gradients
        ConfigurationSection gradientsSection = config.getConfigurationSection("gradients");
        if (gradientsSection != null) {
            for (String key : gradientsSection.getKeys(false)) {
                ConfigurationSection grad = gradientsSection.getConfigurationSection(key);
                if (grad == null) continue;
                List<String> colors = grad.getStringList("colors");
                if (colors.isEmpty()) {
                    // Try as a single string (comma-separated)
                    String colorsStr = grad.getString("colors", "");
                    if (!colorsStr.isEmpty()) {
                        for (String c : colorsStr.split(",")) {
                            colors.add(c.trim());
                        }
                    }
                }
                String permission = grad.getString("permission", "echotab.gradient." + key);
                int priority = grad.getInt("priority", 0);
                gradients.put(key, new GradientPreset(key, colors, permission, priority));
            }
        }

        plugin.getLogger().info("Loaded " + symbols.size() + " symbols and " + gradients.size() + " gradients.");
    }

    /**
     * Checks if a player has a permission EXPLICITLY granted (not via OP).
     *
     * Uses the LuckPerms API if available to bypass OP status. LuckPerms's
     * checkPermission returns Tristate.TRUE only for explicit grants, and
     * Tristate.UNDEFINED for permissions that are "true" only because the
     * player is OP. This prevents OP players from automatically receiving
     * all symbol/gradient presets.
     *
     * Falls back to {@code isPermissionSet() && hasPermission()} if LuckPerms
     * is not installed — this also excludes OPs because isPermissionSet()
     * returns false for OP-granted permissions.
     */
    private boolean hasExplicitPermission(org.bukkit.entity.Player player, String permission) {
        // Primary path: query LuckPerms permission map for an EXACT key match.
        // This bypasses wildcard resolution entirely — echotab.* will NOT trigger
        // echotab.symbol.crown. Only an explicit echotab.symbol.crown = true node counts.
        if (luckPermsHook != null && luckPermsHook.isAvailable()) {
            return luckPermsHook.isExactNodeTrue(player.getUniqueId(), permission);
        }
        // Fallback: Bukkit isPermissionSet() returns false for OP-granted perms,
        // so this combination also excludes OPs.
        return player.isPermissionSet(permission) && player.hasPermission(permission);
    }

    /**
     * Resolves which symbol a player should use based on their EXPLICIT permissions.
     * Returns the highest-priority symbol the player explicitly granted.
     * Returns null if the player has no symbol permission (use default).
     *
     * Note: OP players do NOT automatically get all symbols — they must
     * explicitly grant themselves the ones they want via LuckPerms.
     */
    public SymbolPreset resolveSymbol(org.bukkit.entity.Player player) {
        SymbolPreset best = null;
        for (SymbolPreset symbol : symbols.values()) {
            if (hasExplicitPermission(player, symbol.getPermission())) {
                if (best == null || symbol.getPriority() > best.getPriority()) {
                    best = symbol;
                }
            }
        }
        return best;
    }

    /**
     * Resolves which gradient a player should use based on their EXPLICIT permissions.
     * Returns the highest-priority gradient the player explicitly granted.
     * Returns null if the player has no gradient permission (use default).
     *
     * Note: OP players do NOT automatically get all gradients — they must
     * explicitly grant themselves the ones they want via LuckPerms.
     */
    public GradientPreset resolveGradient(org.bukkit.entity.Player player) {
        GradientPreset best = null;
        for (GradientPreset gradient : gradients.values()) {
            if (hasExplicitPermission(player, gradient.getPermission())) {
                if (best == null || gradient.getPriority() > best.getPriority()) {
                    best = gradient;
                }
            }
        }
        return best;
    }

    /**
     * Gets the default symbol display (or empty string).
     */
    public String getDefaultSymbolDisplay() {
        if (defaultSymbol == null || defaultSymbol.isEmpty()) return "";
        SymbolPreset sym = symbols.get(defaultSymbol);
        return sym != null ? sym.getDisplay() : defaultSymbol;
    }

    /**
     * Gets the default gradient preset (or null).
     */
    public GradientPreset getDefaultGradient() {
        if (defaultGradient == null || defaultGradient.equalsIgnoreCase("none")
                || defaultGradient.isEmpty()) {
            return null;
        }
        return gradients.get(defaultGradient);
    }

    // ─── Getters ────────────────────────────────────────────

    public int getRefreshInterval() { return refreshInterval; }
    public int getJoinDelay() { return joinDelay; }
    public boolean isApplyGradientToName() { return applyGradientToName; }
    public String getDefaultNameColor() { return defaultNameColor; }
    public String getMessagePrefix() { return messagePrefix; }

    public Map<String, SymbolPreset> getSymbols() { return symbols; }
    public Map<String, GradientPreset> getGradients() { return gradients; }

    // ─── Preset Classes ────────────────────────────────────

    public static class SymbolPreset {
        private final String name;
        private final String display;
        private final String permission;
        private final int priority;

        public SymbolPreset(String name, String display, String permission, int priority) {
            this.name = name;
            this.display = display;
            this.permission = permission;
            this.priority = priority;
        }

        public String getName() { return name; }
        public String getDisplay() { return display; }
        public String getPermission() { return permission; }
        public int getPriority() { return priority; }
    }

    public static class GradientPreset {
        private final String name;
        private final List<String> colors;
        private final String permission;
        private final int priority;

        public GradientPreset(String name, List<String> colors, String permission, int priority) {
            this.name = name;
            this.colors = colors != null ? colors : new ArrayList<>();
            this.permission = permission;
            this.priority = priority;
        }

        public String getName() { return name; }
        public List<String> getColors() { return colors; }
        public String getPermission() { return permission; }
        public int getPriority() { return priority; }
    }
}
