package ru.echotab;

import java.util.ArrayList;
import java.util.List;

/**
 * Generates gradient-colored strings by interpolating hex colors
 * across each character of the input text.
 *
 * Output format uses Minecraft hex color codes: &#RRGGBB
 * which the TAB plugin parses and applies per-character.
 *
 * Example:
 *   applyGradient("Nick", ["#FF0000", "#00FF00"])
 *   → "&#FF0000N&#AA0055i&#5500AAk&#00FF00k"
 */
public class GradientGenerator {

    /**
     * Applies a gradient to the given text.
     *
     * @param text  the text to colorize
     * @param colors list of hex colors (#RRGGBB format)
     * @return the gradient-colored string with &#RRGGBB color codes
     */
    public static String applyGradient(String text, List<String> colors) {
        if (text == null || text.isEmpty()) return "";
        if (colors == null || colors.isEmpty()) return text;

        // Single color — apply to entire text
        if (colors.size() == 1) {
            return formatColor(colors.get(0)) + text;
        }

        StringBuilder result = new StringBuilder();
        int n = text.length();
        int segments = colors.size() - 1;

        for (int i = 0; i < n; i++) {
            // Position of this character in the gradient (0.0 to 1.0)
            double t;
            if (n == 1) {
                t = 0;
            } else {
                t = (double) i / (n - 1);
            }

            // Map to segment space
            double pos = t * segments;
            int segIndex = (int) Math.floor(pos);
            if (segIndex >= segments) segIndex = segments - 1;
            double segT = pos - segIndex;

            // Interpolate color
            String color1 = colors.get(segIndex);
            String color2 = colors.get(segIndex + 1);
            String interpolated = interpolateColor(color1, color2, segT);

            result.append(formatColor(interpolated)).append(text.charAt(i));
        }

        return result.toString();
    }

    /**
     * Interpolates between two hex colors.
     *
     * @param c1 first color (#RRGGBB)
     * @param c2 second color (#RRGGBB)
     * @param t  interpolation factor (0.0 = c1, 1.0 = c2)
     * @return interpolated color (#RRGGBB)
     */
    private static String interpolateColor(String c1, String c2, double t) {
        int[] rgb1 = parseHex(c1);
        int[] rgb2 = parseHex(c2);

        int r = (int) Math.round(rgb1[0] + (rgb2[0] - rgb1[0]) * t);
        int g = (int) Math.round(rgb1[1] + (rgb2[1] - rgb1[1]) * t);
        int b = (int) Math.round(rgb1[2] + (rgb2[2] - rgb1[2]) * t);

        return toHex(r, g, b);
    }

    /**
     * Parses a hex color string (#RRGGBB) into RGB components.
     */
    private static int[] parseHex(String hex) {
        String h = hex.startsWith("#") ? hex.substring(1) : hex;
        if (h.length() != 6) {
            // Invalid format, return white
            return new int[]{255, 255, 255};
        }
        try {
            int r = Integer.parseInt(h.substring(0, 2), 16);
            int g = Integer.parseInt(h.substring(2, 4), 16);
            int b = Integer.parseInt(h.substring(4, 6), 16);
            return new int[]{r, g, b};
        } catch (NumberFormatException e) {
            return new int[]{255, 255, 255};
        }
    }

    /**
     * Converts RGB components to a hex color string (#RRGGBB).
     */
    private static String toHex(int r, int g, int b) {
        r = clamp(r);
        g = clamp(g);
        b = clamp(b);
        return String.format("#%02X%02X%02X", r, g, b);
    }

    /**
     * Formats a hex color for Minecraft (prefix with &).
     * TAB parses &#RRGGBB as a hex color code.
     */
    private static String formatColor(String hex) {
        if (hex == null || hex.isEmpty()) return "";
        String h = hex.startsWith("#") ? hex : "#" + hex;
        return "&" + h;
    }

    /**
     * Clamps a value to the 0-255 range.
     */
    private static int clamp(int value) {
        return Math.max(0, Math.min(255, value));
    }

    /**
     * Validates that a color string is a valid hex color.
     */
    public static boolean isValidHex(String hex) {
        if (hex == null) return false;
        String h = hex.startsWith("#") ? hex.substring(1) : hex;
        if (h.length() != 6) return false;
        try {
            Integer.parseInt(h, 16);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Creates a simple 2-color gradient list from a single hex color
     * (for monochrome effects).
     */
    public static List<String> singleColor(String hex) {
        List<String> list = new ArrayList<>();
        list.add(hex);
        return list;
    }
}
