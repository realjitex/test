package ru.echotab.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import ru.echotab.EchoTab;
import ru.echotab.ConfigManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles the /echotab command.
 *
 * Subcommands:
 *   /echotab reload       — reload configuration (admin)
 *   /echotab apply [player] — apply formatting to self or a player
 *   /echotab applyall     — apply formatting to all online players (admin)
 *   /echotab list         — list all available symbols and gradients
 *   /echotab debug        — show LuckPerms hook status and current player preset
 */
public class EchoTabCommand implements CommandExecutor, TabCompleter {

    private final EchoTab plugin;

    private static final List<String> SUBCOMMANDS = Arrays.asList(
            "reload", "apply", "applyall", "list", "debug");

    public EchoTabCommand(EchoTab plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload":
                return handleReload(sender);
            case "apply":
                return handleApply(sender, args);
            case "applyall":
                return handleApplyAll(sender);
            case "list":
                return handleList(sender);
            case "debug":
                return handleDebug(sender, args);
            default:
                sendHelp(sender);
                return true;
        }
    }

    /**
     * /echotab reload — reloads the configuration.
     */
    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("echotab.admin")) {
            plugin.sendMessage(sender, plugin.getConfig().getString("messages.no-permission",
                    "&cYou don't have permission."));
            return true;
        }

        plugin.reloadPluginConfig();
        plugin.sendMessage(sender, plugin.getConfig().getString("messages.config-reloaded",
                "&aConfiguration reloaded successfully."));
        return true;
    }

    /**
     * /echotab apply [player] — applies formatting to self or target.
     */
    private boolean handleApply(CommandSender sender, String[] args) {
        Player target;

        if (args.length >= 2) {
            // Apply to specified player
            if (!sender.hasPermission("echotab.admin")) {
                plugin.sendMessage(sender, plugin.getConfig().getString("messages.no-permission",
                        "&cYou don't have permission."));
                return true;
            }
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
                String msg = plugin.getConfig().getString("messages.player-not-found",
                        "&cPlayer not found: &e{player}");
                plugin.sendMessage(sender, msg.replace("{player}", args[1]));
                return true;
            }
        } else {
            // Apply to self
            if (!(sender instanceof Player)) {
                plugin.sendMessage(sender, "&cUsage: /echotab apply <player>");
                return true;
            }
            target = (Player) sender;
        }

        plugin.getTabFormatter().applyFormatting(target);
        String msg = plugin.getConfig().getString("messages.applied",
                "&aFormatting applied to &e{player}&a.");
        plugin.sendMessage(sender, msg.replace("{player}", target.getName()));
        return true;
    }

    /**
     * /echotab applyall — applies formatting to all online players.
     */
    private boolean handleApplyAll(CommandSender sender) {
        if (!sender.hasPermission("echotab.admin")) {
            plugin.sendMessage(sender, plugin.getConfig().getString("messages.no-permission",
                    "&cYou don't have permission."));
            return true;
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            plugin.getTabFormatter().applyFormatting(player);
        }
        plugin.sendMessage(sender, plugin.getConfig().getString("messages.applied-all",
                "&aFormatting applied to all online players."));
        return true;
    }

    /**
     * /echotab list — lists all available symbols and gradients.
     */
    private boolean handleList(CommandSender sender) {
        plugin.sendMessage(sender, plugin.getConfig().getString("messages.list-header",
                "&b═══ EchoTab Presets ═══"));

        // Symbols
        StringBuilder symbolsLine = new StringBuilder();
        symbolsLine.append(plugin.getConfig().getString("messages.list-symbols", "&eSymbols:&r "));
        for (String name : plugin.getConfigManager().getSymbols().keySet()) {
            symbolsLine.append(name).append(", ");
        }
        // Remove trailing comma
        String symStr = symbolsLine.toString();
        if (symStr.endsWith(", ")) {
            symStr = symStr.substring(0, symStr.length() - 2);
        }
        sender.sendMessage(EchoTab.colorize(symStr));

        // Gradients
        StringBuilder gradientsLine = new StringBuilder();
        gradientsLine.append(plugin.getConfig().getString("messages.list-gradients", "&eGradients:&r "));
        for (String name : plugin.getConfigManager().getGradients().keySet()) {
            gradientsLine.append(name).append(", ");
        }
        String gradStr = gradientsLine.toString();
        if (gradStr.endsWith(", ")) {
            gradStr = gradStr.substring(0, gradStr.length() - 2);
        }
        sender.sendMessage(EchoTab.colorize(gradStr));

        return true;
    }

    /**
     * /echotab debug [player] — shows LuckPerms hook status and current player preset.
     */
    private boolean handleDebug(CommandSender sender, String[] args) {
        org.bukkit.entity.Player target = null;
        if (args.length >= 2) {
            target = Bukkit.getPlayerExact(args[1]);
        } else if (sender instanceof org.bukkit.entity.Player) {
            target = (org.bukkit.entity.Player) sender;
        }

        sender.sendMessage(EchoTab.colorize("&b═══ EchoTab Debug ═══"));

        // LuckPerms hook status
        ru.echotab.LuckPermsHook hook = plugin.getLuckPermsHook();
        sender.sendMessage(EchoTab.colorize("&eLuckPerms hook available: &f" + hook.isAvailable()));
        sender.sendMessage(EchoTab.colorize("&eTAB feature enabled: &f" + plugin.getTabFormatter().isTabFeatureEnabled()));

        if (target == null) {
            sender.sendMessage(EchoTab.colorize("&7Specify a player to see their preset."));
            return true;
        }

        sender.sendMessage(EchoTab.colorize("&eTarget: &f" + target.getName()));

        // Show resolved symbol and gradient
        ru.echotab.ConfigManager.SymbolPreset symbol = plugin.getConfigManager().resolveSymbol(target);
        ru.echotab.ConfigManager.GradientPreset gradient = plugin.getConfigManager().resolveGradient(target);

        sender.sendMessage(EchoTab.colorize("&eResolved symbol: &f" + (symbol != null ? symbol.getName() : "(none/default)")));
        if (symbol != null) {
            sender.sendMessage(EchoTab.colorize("  &7perm: &f" + symbol.getPermission() + " &7priority: " + symbol.getPriority()));
            // Show WHERE this permission comes from (group/wildcard/direct)
            String permDebug = plugin.getLuckPermsHook().getPermissionDebug(
                    target.getUniqueId(), symbol.getPermission());
            sender.sendMessage(EchoTab.colorize("  &7source:"));
            for (String line : permDebug.split("\n")) {
                if (!line.isEmpty()) {
                    sender.sendMessage(EchoTab.colorize("    &8" + line));
                }
            }
        }
        sender.sendMessage(EchoTab.colorize("&eResolved gradient: &f" + (gradient != null ? gradient.getName() : "(none/default)")));
        if (gradient != null) {
            sender.sendMessage(EchoTab.colorize("  &7perm: &f" + gradient.getPermission() + " &7priority: " + gradient.getPriority()));
            // Show WHERE this permission comes from
            String permDebug = plugin.getLuckPermsHook().getPermissionDebug(
                    target.getUniqueId(), gradient.getPermission());
            sender.sendMessage(EchoTab.colorize("  &7source:"));
            for (String line : permDebug.split("\n")) {
                if (!line.isEmpty()) {
                    sender.sendMessage(EchoTab.colorize("    &8" + line));
                }
            }
        }

        // Show default
        sender.sendMessage(EchoTab.colorize("&eDefault symbol: &f" + plugin.getConfig().getString("defaults.symbol", "")));
        sender.sendMessage(EchoTab.colorize("&eDefault gradient: &f" + plugin.getConfig().getString("defaults.gradient", "white")));

        // Show raw echotab permission map entries (exact nodes, no wildcard expansion)
        sender.sendMessage(EchoTab.colorize("&eRaw echotab permission nodes (exact matches only):"));
        java.util.Map<String, Boolean> permMap = plugin.getLuckPermsHook()
                .getPermissionMapSnapshot(target.getUniqueId());
        if (permMap.isEmpty()) {
            sender.sendMessage(EchoTab.colorize("  &7(none — no echotab permissions set)"));
        } else {
            for (java.util.Map.Entry<String, Boolean> entry : permMap.entrySet()) {
                String color = entry.getValue() ? "&a" : "&c";
                sender.sendMessage(EchoTab.colorize("  " + color + entry.getKey() + " = " + entry.getValue()));
            }
        }

        return true;
    }

    /**
     * Sends the help message.
     */
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(EchoTab.colorize("&b═══ EchoTab Help ═══"));
        sender.sendMessage(EchoTab.colorize("&e/echotab reload &7— Reload configuration"));
        sender.sendMessage(EchoTab.colorize("&e/echotab apply [player] &7— Apply formatting"));
        sender.sendMessage(EchoTab.colorize("&e/echotab applyall &7— Apply to all players"));
        sender.sendMessage(EchoTab.colorize("&e/echotab list &7— List symbols & gradients"));
        sender.sendMessage(EchoTab.colorize("&e/echotab debug [player] &7— Show LuckPerms hook status & current preset"));
        sender.sendMessage(EchoTab.colorize("&7Assign via LuckPerms: &fechotab.symbol.<name> &7and &fechotab.gradient.<name>"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return SUBCOMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("apply")) {
            // Suggest online player names
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase().startsWith(args[1].toLowerCase())) {
                    names.add(player.getName());
                }
            }
            return names;
        }

        return new ArrayList<>();
    }
}
