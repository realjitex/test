package ru.echotab;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Applies symbol prefix and gradient nickname to players via the TAB plugin API.
 *
 * Uses TAB v5 API (via reflection) to set:
 *   - TabListFormatManager.setPrefix(player, symbol)  → symbol prefix
 *   - TabListFormatManager.setName(player, gradientName) → gradient-colored name
 *
 * The suffix is left untouched (managed by StatusPlugin or other plugins).
 *
 * If TAB is not available, falls back to Bukkit's setPlayerListName
 * (combining symbol + gradient name into the list name).
 */
public class TabFormatter {

    private final EchoTab plugin;
    private final ConfigManager configManager;

    // TAB availability and reflection caches
    private boolean tabChecked = false;
    private boolean tabAvailable = false;
    private boolean tabFeatureDisabled = false;
    private boolean featureDisabledWarned = false;

    // Reflection method handles
    private Method getInstanceMethod;
    private Method getPlayerMethod;
    private Method getTabListFormatManagerMethod;
    private Method setPrefixMethod;
    private Method setNameMethod;
    private Method setSuffixMethod;

    // Bukkit fallback: stores original player list names
    private final ConcurrentHashMap<UUID, String> originalListNames;

    public TabFormatter(EchoTab plugin, ConfigManager configManager) {
        this.plugin = plugin;
        this.configManager = configManager;
        this.originalListNames = new ConcurrentHashMap<>();
    }

    /**
     * Checks if the TAB plugin is available and caches reflection methods.
     */
    private void checkTabAvailability() {
        if (tabChecked) return;
        tabChecked = true;

        if (Bukkit.getPluginManager().getPlugin("TAB") == null) {
            tabAvailable = false;
            return;
        }

        try {
            Class<?> tabAPIClass = Class.forName("me.neznamy.tab.api.TabAPI");

            getInstanceMethod = tabAPIClass.getMethod("getInstance");

            try {
                getPlayerMethod = tabAPIClass.getMethod("getPlayer", UUID.class);
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find TabAPI.getPlayer(UUID) method.");
                tabAvailable = false;
                return;
            }

            try {
                getTabListFormatManagerMethod = tabAPIClass.getMethod("getTabListFormatManager");
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find TabAPI.getTabListFormatManager() method.");
                tabAvailable = false;
                return;
            }

            Class<?> tabPlayerClass = getPlayerMethod.getReturnType();
            Class<?> tabListFormatManagerClass = getTabListFormatManagerMethod.getReturnType();

            if (tabListFormatManagerClass == void.class || tabListFormatManagerClass == null) {
                plugin.getLogger().warning("TabListFormatManager class not found.");
                tabAvailable = false;
                return;
            }

            // setPrefix(TabPlayer, String)
            try {
                setPrefixMethod = tabListFormatManagerClass.getMethod("setPrefix", tabPlayerClass, String.class);
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find TabListFormatManager.setPrefix method.");
                tabAvailable = false;
                return;
            }

            // setName(TabPlayer, String)
            try {
                setNameMethod = tabListFormatManagerClass.getMethod("setName", tabPlayerClass, String.class);
            } catch (NoSuchMethodException e) {
                plugin.getLogger().warning("Could not find TabListFormatManager.setName method.");
                tabAvailable = false;
                return;
            }

            // setSuffix(TabPlayer, String) — optional, for clearing
            try {
                setSuffixMethod = tabListFormatManagerClass.getMethod("setSuffix", tabPlayerClass, String.class);
            } catch (NoSuchMethodException e) {
                setSuffixMethod = null;
            }

            tabAvailable = true;
            plugin.getLogger().info("TAB v5 API hooked successfully (EchoTab).");

        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("TAB API class not found. " + e.getMessage());
            tabAvailable = false;
        } catch (Exception e) {
            plugin.getLogger().warning("Failed to hook into TAB API: " + e.getMessage());
            tabAvailable = false;
        }
    }

    /**
     * Applies the symbol prefix and gradient nickname to a player.
     *
     * @param player the player to format
     */
    public void applyFormatting(Player player) {
        checkTabAvailability();

        // Resolve symbol and gradient from permissions
        ConfigManager.SymbolPreset symbolPreset = configManager.resolveSymbol(player);
        ConfigManager.GradientPreset gradientPreset = configManager.resolveGradient(player);

        // Determine the symbol display
        String symbolDisplay;
        if (symbolPreset != null) {
            symbolDisplay = symbolPreset.getDisplay();
        } else {
            symbolDisplay = configManager.getDefaultSymbolDisplay();
        }

        // Determine the gradient to apply to the name
        ConfigManager.GradientPreset effectiveGradient = gradientPreset;
        if (effectiveGradient == null) {
            effectiveGradient = configManager.getDefaultGradient();
        }

        // Build the gradient-colored name
        String playerName = player.getName();
        String formattedName;
        if (effectiveGradient != null && configManager.isApplyGradientToName()) {
            formattedName = GradientGenerator.applyGradient(playerName, effectiveGradient.getColors());
        } else {
            // No gradient — apply default color
            formattedName = configManager.getDefaultNameColor() + playerName;
        }

        // Colorize the symbol
        String symbolColored = EchoTab.colorize(symbolDisplay);
        String nameColored = EchoTab.colorize(formattedName);

        if (tabAvailable && !tabFeatureDisabled) {
            applyViaTab(player, symbolColored, nameColored);
        } else {
            applyViaBukkit(player, symbolColored, nameColored);
        }
    }

    /**
     * Applies formatting via the TAB v5 API (reflection).
     */
    private void applyViaTab(Player player, String symbol, String name) {
        try {
            Object tabAPI = getInstanceMethod.invoke(null);
            Object manager = getTabListFormatManagerMethod.invoke(tabAPI);

            if (manager == null) {
                // Feature disabled
                if (!featureDisabledWarned) {
                    featureDisabledWarned = true;
                    tabFeatureDisabled = true;
                    plugin.getLogger().warning("");
                    plugin.getLogger().warning("╔════════════════════════════════════════════════════════════╗");
                    plugin.getLogger().warning("║ TAB 'tablist-name-formatting' feature is DISABLED!        ║");
                    plugin.getLogger().warning("║                                                              ║");
                    plugin.getLogger().warning("║ EchoTab cannot apply formatting via TAB.                     ║");
                    plugin.getLogger().warning("║ Falling back to Bukkit player list name.                     ║");
                    plugin.getLogger().warning("║                                                              ║");
                    plugin.getLogger().warning("║ To fix: enable 'tablist-name-formatting' in TAB's config:   ║");
                    plugin.getLogger().warning("║   plugins/TAB/config.yml                                     ║");
                    plugin.getLogger().warning("║   tablist-name-formatting:                                   ║");
                    plugin.getLogger().warning("║     enabled: true                                            ║");
                    plugin.getLogger().warning("╚════════════════════════════════════════════════════════════╝");
                    plugin.getLogger().warning("");
                }
                applyViaBukkit(player, symbol, name);
                return;
            }

            Object tabPlayer = getPlayerMethod.invoke(tabAPI, player.getUniqueId());
            if (tabPlayer == null) {
                // Player not loaded yet — retry after delay
                Bukkit.getScheduler().runTaskLater(plugin, () -> applyFormatting(player), 20L);
                return;
            }

            // Set the symbol as the prefix
            if (symbol == null || symbol.isEmpty()) {
                setPrefixMethod.invoke(manager, tabPlayer, (Object) null);
            } else {
                setPrefixMethod.invoke(manager, tabPlayer, symbol);
            }

            // Set the gradient-colored name
            setNameMethod.invoke(manager, tabPlayer, name);

        } catch (Exception e) {
            plugin.getLogger().warning("Error applying TAB formatting for " + player.getName() + ": " + e.getMessage());
            applyViaBukkit(player, symbol, name);
        }
    }

    /**
     * Applies formatting via Bukkit's setPlayerListName (fallback).
     * Combines symbol + gradient name into the list name.
     */
    private void applyViaBukkit(Player player, String symbol, String name) {
        UUID uuid = player.getUniqueId();

        // Save original name on first modification
        if (!originalListNames.containsKey(uuid)) {
            originalListNames.put(uuid, player.getPlayerListName() != null ? player.getPlayerListName() : player.getName());
        }

        String combined = (symbol != null ? symbol : "") + name;

        try {
            player.setPlayerListName(combined);
        } catch (IllegalArgumentException e) {
            // Name too long — truncate
            int maxLen = 16;
            if (combined.length() > maxLen) {
                combined = combined.substring(0, maxLen);
            }
            try {
                player.setPlayerListName(combined);
            } catch (IllegalArgumentException e2) {
                // Give up
            }
        }
    }

    /**
     * Restores the original tab display for a player (called on quit).
     */
    public void restoreFormatting(Player player) {
        checkTabAvailability();

        if (tabAvailable && !tabFeatureDisabled) {
            try {
                Object tabAPI = getInstanceMethod.invoke(null);
                Object manager = getTabListFormatManagerMethod.invoke(tabAPI);
                if (manager != null) {
                    Object tabPlayer = getPlayerMethod.invoke(tabAPI, player.getUniqueId());
                    if (tabPlayer != null) {
                        // Reset prefix and name to original (null = reset)
                        setPrefixMethod.invoke(manager, tabPlayer, (Object) null);
                        setNameMethod.invoke(manager, tabPlayer, (Object) null);
                    }
                }
            } catch (Exception e) {
                // Ignore errors during cleanup
            }
        } else {
            // Restore original Bukkit player list name
            UUID uuid = player.getUniqueId();
            String original = originalListNames.remove(uuid);
            if (original != null) {
                try {
                    player.setPlayerListName(original);
                } catch (IllegalArgumentException e) {
                    // Ignore
                }
            }
        }
    }

    /**
     * Returns whether the TAB plugin is available.
     */
    public boolean isTabAvailable() {
        checkTabAvailability();
        return tabAvailable;
    }

    /**
     * Returns whether the TAB tablist-formatting feature is enabled.
     */
    public boolean isTabFeatureEnabled() {
        checkTabAvailability();
        return tabAvailable && !tabFeatureDisabled;
    }
}
