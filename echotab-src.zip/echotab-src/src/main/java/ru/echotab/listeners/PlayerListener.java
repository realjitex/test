package ru.echotab.listeners;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import ru.echotab.EchoTab;

/**
 * Listens for player join/quit events to apply/restore EchoTab formatting.
 *
 * On join, formatting is applied after a configurable delay (to ensure TAB
 * has loaded the player's TabPlayer object).
 * On quit, the original tab display is restored to avoid leftover formatting.
 */
public class PlayerListener implements Listener {

    private final EchoTab plugin;

    public PlayerListener(EchoTab plugin) {
        this.plugin = plugin;
    }

    /**
     * Handles player join — applies formatting after a delay.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        int delay = plugin.getConfigManager().getJoinDelay();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            // Verify the player is still online
            if (event.getPlayer().isOnline()) {
                plugin.getTabFormatter().applyFormatting(event.getPlayer());
            }
        }, delay);
    }

    /**
     * Handles player quit — restores original tab display.
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        plugin.getTabFormatter().restoreFormatting(event.getPlayer());
    }
}
