import ru.realjitex.echomenu.MenuLayout;
import java.util.HashMap;
import java.util.Map;

public class LayoutCheck {
    public static void main(String[] args) {
        String[][] expected = {
            {"world", "accessories", "cases"},
            {"world", "accessories", "cases"},
            {"world", "lobby", "cases"},
            {"farms", "lobby", "end"},
            {"farms", "lobby", "end"},
            {"farms", "lobby", "end"}
        };
        Map<String, Integer> counts = new HashMap<>();
        for (int row = 0; row < 6; row++) {
            for (int col = 0; col < 9; col++) {
                String actual = MenuLayout.buttonAt(row * 9 + col);
                if (!actual.equals(expected[row][col / 3])) throw new AssertionError("Slot " + (row * 9 + col));
                counts.merge(actual, 1, Integer::sum);
            }
        }
        for (int invalid : new int[]{-999, -1, 54, 60, 89, 90, Integer.MAX_VALUE}) {
            if (!MenuLayout.buttonAt(invalid).isEmpty()) throw new AssertionError("Outside slot " + invalid);
        }
        if (counts.get("world") != 9 || counts.get("lobby") != 12) throw new AssertionError(counts);
        System.out.println("PASS: all 54 slots, asymmetric lobby button and player/outside slots.");
    }
}
