package ru.realjitex.echomenu;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;

/** No item models, custom-model-data, global font overrides or NMS. */
public final class EchoMenu extends JavaPlugin implements Listener {
    private static final Key MENU_FONT = Key.key("echomenu", "menu");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getMessenger().registerOutgoingPluginChannel(this, "BungeeCord");
        getServer().getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("menu")).setExecutor(this);
        Objects.requireNonNull(getCommand("echomenu")).setExecutor(this);
    }

    @Override
    public void onDisable() {
        closeMenus();
        getServer().getMessenger().unregisterOutgoingPluginChannel(this);
    }

    private void closeMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getOpenInventory().getTopInventory().getHolder() instanceof MenuHolder) {
                player.closeInventory();
            }
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("echomenu") && args.length == 1
                && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("echomenu.admin")) {
                sender.sendMessage(Component.text("Нет прав.", NamedTextColor.RED));
                return true;
            }
            closeMenus();
            reloadConfig();
            sender.sendMessage(Component.text("EchoMenu: конфигурация перечитана.", NamedTextColor.GREEN));
            return true;
        }
        if (args.length != 0) {
            sender.sendMessage(Component.text("/menu | /echomenu reload", NamedTextColor.GRAY));
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Эта команда доступна только игроку.");
            return true;
        }
        if (!player.hasPermission("echomenu.use")) {
            tell(player, "no-permission", "Нет прав.");
            return true;
        }
        openMenu(player);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("echomenu") && sender.hasPermission("echomenu.admin")
                && args.length == 1 && "reload".startsWith(args[0].toLowerCase(Locale.ROOT))) {
            return List.of("reload");
        }
        return List.of();
    }

    private void openMenu(Player player) {
        // Explicit font and WHITE avoid the vanilla dark-gray inventory-title tint.
        Component title = Component.text("\uE001\uE000", NamedTextColor.WHITE).font(MENU_FONT);
        MenuHolder holder = new MenuHolder(player.getUniqueId(), title);
        player.openInventory(holder.getInventory());
    }

    @EventHandler(ignoreCancelled = false)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) return;
        // Also block shift-click, number keys, offhand swap, double-click and outside drops.
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!holder.owner.equals(player.getUniqueId()) || holder.pending) return;
        if (!event.isLeftClick() && !event.isRightClick()) return;
        if (event.isShiftClick()) return;
        String button = MenuLayout.buttonAt(event.getRawSlot());
        if (button.isEmpty()) return;
        if (!button.equals("world") && !button.equals("lobby")) {
            tell(player, "soon", "Этот раздел пока недоступен.");
            return;
        }
        if (!player.hasPermission("echomenu.use")) {
            tell(player, "no-permission", "Нет прав.");
            return;
        }
        // Opening/closing inventories from InventoryClickEvent must be deferred.
        holder.pending = true;
        Bukkit.getScheduler().runTask(this, () -> {
            if (!player.isOnline() || player.getOpenInventory().getTopInventory().getHolder() != holder) return;
            try {
                navigate(player, button);
            } finally {
                holder.pending = false;
            }
        });
    }

    @EventHandler(ignoreCancelled = false)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder) event.setCancelled(true);
    }

    private void navigate(Player player, String button) {
        String base = "destinations." + button + ".";
        String mode = getConfig().getString(base + "mode", "SERVER").toUpperCase(Locale.ROOT);
        if (mode.equals("SERVER")) {
            String target = getConfig().getString(base + "server", "").trim();
            if (target.isEmpty() || target.startsWith("CHANGE_ME")) {
                tell(player, "not-configured", "Переход ещё не настроен администратором.");
                return;
            }
            if (target.equalsIgnoreCase(getConfig().getString("current-server", ""))) {
                tell(player, "already-there", "Ты уже здесь.");
                return;
            }
            try {
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                try (DataOutputStream out = new DataOutputStream(bytes)) {
                    out.writeUTF("Connect");
                    out.writeUTF(target);
                }
                player.closeInventory();
                player.sendPluginMessage(this, "BungeeCord", bytes.toByteArray());
                // The channel provides no acknowledgement: never claim a successful transfer.
                tell(player, "connecting", "Запрос перехода отправлен…");
            } catch (IOException exception) {
                getLogger().warning("Cannot encode server transfer: " + exception.getMessage());
                tell(player, "failed", "Не удалось выполнить переход.");
            }
            return;
        }
        if (mode.equals("WORLD")) {
            World world = Bukkit.getWorld(getConfig().getString(base + "world", ""));
            if (world == null) {
                tell(player, "not-configured", "Переход ещё не настроен администратором.");
                return;
            }
            if (player.getWorld().equals(world)) {
                tell(player, "already-there", "Ты уже здесь.");
                return;
            }
            Location location = world.getSpawnLocation();
            player.closeInventory();
            player.teleportAsync(location).thenAccept(success -> {
                if (!success) Bukkit.getScheduler().runTask(this, () -> {
                    if (player.isOnline()) tell(player, "failed", "Не удалось выполнить переход.");
                });
            });
            return;
        }
        getLogger().warning("Unknown destination mode for " + button + ": " + mode);
        tell(player, "not-configured", "Переход ещё не настроен администратором.");
    }

    private void tell(Player player, String key, String fallback) {
        player.sendMessage(Component.text(getConfig().getString("messages." + key, fallback), NamedTextColor.GRAY));
    }

    private static final class MenuHolder implements InventoryHolder {
        private final UUID owner;
        private final Inventory inventory;
        private boolean pending;

        private MenuHolder(UUID owner, Component title) {
            this.owner = owner;
            this.inventory = Bukkit.createInventory(this, 54, title);
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }
}
