package ru.realjitex.echomenu;

/** Slot coordinates follow the supplied 256x256 texture, drawn at (-8, -9). */
public final class MenuLayout {
    private MenuLayout() {}

    public static String buttonAt(int slot) {
        if (slot < 0 || slot >= 54) return "";
        int row = slot / 9;
        int column = slot % 9;
        if (column < 3) return row < 3 ? "world" : "farms";
        if (column < 6) return row < 2 ? "accessories" : "lobby";
        return row < 3 ? "cases" : "end";
    }
}
