@echo off
cd /d "%~dp0"
where mvn >nul 2>&1
if errorlevel 1 (
  echo Install JDK 21 and Maven, or use the included GitHub Actions workflow.
  pause
  exit /b 1
)
call mvn --batch-mode --no-transfer-progress clean package
if errorlevel 1 (
  pause
  exit /b 1
)
echo Ready: target\EchoMenu-1.0.0.jar
pause
