#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mvn --batch-mode --no-transfer-progress clean package
