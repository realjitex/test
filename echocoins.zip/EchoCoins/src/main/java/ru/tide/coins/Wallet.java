package ru.tide.coins;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

final class Wallet {
    static final long MAX = 1_000_000_000_000L;
    private final Map<UUID, Long> balances = new HashMap<>();
    long get(UUID id) { return balances.getOrDefault(id, 0L); }
    void set(UUID id, long amount) {
        if (amount < 0 || amount > MAX) throw new IllegalArgumentException("Баланс должен быть от 0 до " + MAX);
        balances.put(id, amount);
    }
    void add(UUID id, long amount) { set(id, Math.addExact(get(id), amount)); }
    void transfer(UUID from, UUID to, long amount) {
        if (from.equals(to) || amount <= 0) throw new IllegalArgumentException("Неверный перевод");
        long a = get(from), b = get(to);
        if (a < amount) throw new IllegalArgumentException("Недостаточно монет");
        if (amount > MAX - b) throw new IllegalArgumentException("Превышен лимит получателя");
        set(from, a - amount); set(to, b + amount);
    }
    Map<UUID, Long> snapshot() { return new HashMap<>(balances); }
    void restore(Map<UUID, Long> saved) { balances.clear(); balances.putAll(saved); }
}
