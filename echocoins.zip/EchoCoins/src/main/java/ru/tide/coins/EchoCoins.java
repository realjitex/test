package ru.tide.coins;

import java.nio.file.*;
import java.util.*;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;

public class EchoCoins extends JavaPlugin {
    private final Wallet wallet = new Wallet();
    private Path file;
    @Override public void onEnable() {
        file = getDataFolder().toPath().resolve("balances.yml");
        try {
            Files.createDirectories(file.getParent());
            if (Files.exists(file)) {
                var yaml = new YamlConfiguration(); yaml.load(file.toFile());
                for (String key : yaml.getKeys(false)) {
                    Object value = yaml.get(key);
                    if (!(value instanceof Number n) || n.doubleValue() != n.longValue()) throw new IllegalArgumentException("Неверный баланс " + key);
                    wallet.set(UUID.fromString(key), n.longValue());
                }
            }
        } catch (Exception e) {
            getLogger().severe("Не удалось загрузить balances.yml; файл не перезаписан: " + e);
            Bukkit.getPluginManager().disablePlugin(this); return;
        }
        Objects.requireNonNull(getCommand("coins")).setExecutor(this);
    }
    public long balance(UUID player) { return wallet.get(player); }
    /** Main-thread API. Returns false on invalid amount or disk error; balance is rolled back. */
    public boolean deposit(UUID player, long amount) {
        return amount > 0 && transaction(() -> wallet.add(player, amount));
    }
    public boolean withdraw(UUID player, long amount) {
        return amount > 0 && transaction(() -> wallet.add(player, -amount));
    }
    private boolean transaction(Runnable mutation) {
        if (!isEnabled() || !Bukkit.isPrimaryThread()) return false;
        var before = wallet.snapshot();
        try {
            mutation.run();
            var yaml = new YamlConfiguration();
            wallet.snapshot().forEach((id, amount) -> yaml.set(id.toString(), amount));
            Path temp = file.resolveSibling("balances.yml.tmp");
            yaml.save(temp.toFile());
            try { Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (Exception e) {
            wallet.restore(before);
            if (!(e instanceof IllegalArgumentException)) getLogger().severe("Ошибка сохранения монет: " + e);
            return false;
        }
    }
    private void say(CommandSender s, String msg) { s.sendMessage(Component.text("EchoCoins » " + msg, NamedTextColor.GOLD)); }
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player p) say(p, "Баланс: " + balance(p.getUniqueId()) + " монет.");
            else say(sender, "/coins balance <игрок> | give/take <игрок> <сумма>");
            return true;
        }
        if (args[0].equalsIgnoreCase("balance") && args.length == 2) {
            Player p = Bukkit.getPlayerExact(args[1]);
            if (p == null) say(sender, "Игрок должен быть онлайн.");
            else say(sender, p.getName() + ": " + balance(p.getUniqueId()) + " монет.");
            return true;
        }
        if (args.length == 3) {
            String action = args[0].toLowerCase(Locale.ROOT);
            if (!List.of("pay", "give", "take").contains(action)) { say(sender, "Команды: balance, pay, give, take."); return true; }
            if (!action.equals("pay") && !sender.hasPermission("echocoins.admin")) { say(sender, "Нет прав."); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { say(sender, "Получатель должен быть онлайн."); return true; }
            long amount;
            try { amount = Long.parseLong(args[2]); if (amount <= 0 || amount > Wallet.MAX) throw new NumberFormatException(); }
            catch (NumberFormatException e) { say(sender, "Укажи целое положительное число до " + Wallet.MAX + "."); return true; }
            boolean ok;
            if (action.equals("pay")) {
                if (!(sender instanceof Player p)) { say(sender, "Перевод доступен игрокам."); return true; }
                ok = transaction(() -> wallet.transfer(p.getUniqueId(), target.getUniqueId(), amount));
            } else ok = action.equals("give") ? deposit(target.getUniqueId(), amount) : withdraw(target.getUniqueId(), amount);
            say(sender, ok ? "Готово: " + action + " " + target.getName() + " — " + amount + " монет." : "Операция отклонена: проверь баланс, получателя и лимит; при ошибке диска смотри консоль.");
            if (ok && !sender.equals(target)) say(target, "Баланс изменён. Сейчас: " + balance(target.getUniqueId()) + " монет.");
            return true;
        }
        say(sender, "/coins | /coins balance <игрок> | /coins pay <игрок> <сумма>");
        if (sender.hasPermission("echocoins.admin")) say(sender, "/coins give/take <игрок> <сумма>");
        return true;
    }
    @Override public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
        List<String> choices = args.length == 1 ? (s.hasPermission("echocoins.admin") ? List.of("balance", "pay", "give", "take") : List.of("balance", "pay")) : args.length == 2 ? Bukkit.getOnlinePlayers().stream().map(Player::getName).toList() : List.of();
        return choices.stream().filter(x -> x.toLowerCase(Locale.ROOT).startsWith(args[args.length - 1].toLowerCase(Locale.ROOT))).toList();
    }
}

