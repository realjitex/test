package ru.tide.coins;
import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
class WalletTest {
    @Test void transfersConserveMoney() {
        Wallet w = new Wallet(); UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        w.add(a, 500); w.transfer(a, b, 125);
        assertEquals(375, w.get(a)); assertEquals(125, w.get(b));
    }
    @Test void rejectedTransfersNeverMutateEitherAccount() {
        Wallet w = new Wallet(); UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        w.set(a, 20); w.set(b, Wallet.MAX);
        var before = w.snapshot();
        assertThrows(IllegalArgumentException.class, () -> w.transfer(a, b, 1));
        assertThrows(IllegalArgumentException.class, () -> w.transfer(a, b, 21));
        assertThrows(IllegalArgumentException.class, () -> w.transfer(a, a, 1));
        assertThrows(IllegalArgumentException.class, () -> w.transfer(a, b, -5));
        assertEquals(before, w.snapshot());
    }
    @Test void rollbackAndBounds() {
        Wallet w = new Wallet(); UUID a = UUID.randomUUID(); w.set(a, 100);
        var saved = w.snapshot(); w.add(a, 20); w.restore(saved); assertEquals(100, w.get(a));
        assertThrows(IllegalArgumentException.class, () -> w.add(a, -101));
        assertThrows(ArithmeticException.class, () -> w.add(a, Long.MAX_VALUE));
        assertEquals(100, w.get(a));
    }
}
